/**
 * Generic handler for controller errors.
 * Automatically maps validation and casting errors (e.g. invalid ObjectIds)
 * to a 400 Bad Request, and other errors to 500 Internal Server Error.
 */
const handleControllerError = (res, error) => {
  if (error.name === 'ValidationError' || error.name === 'CastError') {
    return res.status(400).json({ message: error.message });
  }
  return res.status(500).json({ message: error.message });
};

module.exports = { handleControllerError };

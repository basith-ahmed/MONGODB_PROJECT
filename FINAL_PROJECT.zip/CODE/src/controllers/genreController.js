const Genre = require('../models/Genre');
const { handleControllerError } = require('../utils/errorHandler');

exports.createGenre = async (req, res) => {
  try {
    const genre = await Genre.create(req.body);
    res.status(201).json(genre);
  } catch (error) {
    handleControllerError(res, error);
  }
};

exports.getGenres = async (req, res) => {
  try {
    const genres = await Genre.find({});
    res.json(genres);
  } catch (error) {
    handleControllerError(res, error);
  }
};

exports.getGenreById = async (req, res) => {
  try {
    const genre = await Genre.findById(req.params.id);
    if (genre) {
      res.json(genre);
    } else {
      res.status(404).json({ message: 'Genre not found' });
    }
  } catch (error) {
    handleControllerError(res, error);
  }
};

exports.updateGenre = async (req, res) => {
  try {
    const genre = await Genre.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true,
    });
    if (genre) {
      res.json(genre);
    } else {
      res.status(404).json({ message: 'Genre not found' });
    }
  } catch (error) {
    handleControllerError(res, error);
  }
};

exports.deleteGenre = async (req, res) => {
  try {
    const genre = await Genre.findByIdAndDelete(req.params.id);
    if (genre) {
      res.json({ message: 'Genre removed' });
    } else {
      res.status(404).json({ message: 'Genre not found' });
    }
  } catch (error) {
    handleControllerError(res, error);
  }
};

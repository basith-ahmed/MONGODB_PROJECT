const Actor = require('../models/Actor');
const { handleControllerError } = require('../utils/errorHandler');

exports.createActor = async (req, res) => {
  try {
    const actor = await Actor.create(req.body);
    res.status(201).json(actor);
  } catch (error) {
    handleControllerError(res, error);
  }
};

exports.getActors = async (req, res) => {
  try {
    const actors = await Actor.find({});
    res.json(actors);
  } catch (error) {
    handleControllerError(res, error);
  }
};

exports.getActorById = async (req, res) => {
  try {
    const actor = await Actor.findById(req.params.id);
    if (actor) {
      res.json(actor);
    } else {
      res.status(404).json({ message: 'Actor not found' });
    }
  } catch (error) {
    handleControllerError(res, error);
  }
};

exports.updateActor = async (req, res) => {
  try {
    const actor = await Actor.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true,
    });
    if (actor) {
      res.json(actor);
    } else {
      res.status(404).json({ message: 'Actor not found' });
    }
  } catch (error) {
    handleControllerError(res, error);
  }
};

exports.deleteActor = async (req, res) => {
  try {
    const actor = await Actor.findByIdAndDelete(req.params.id);
    if (actor) {
      res.json({ message: 'Actor removed' });
    } else {
      res.status(404).json({ message: 'Actor not found' });
    }
  } catch (error) {
    handleControllerError(res, error);
  }
};

const User = require('../models/User');
const { handleControllerError } = require('../utils/errorHandler');

exports.addMovieToWatchlist = async (req, res) => {
  try {
    const { movieId } = req.body;
    const user = await User.findById(req.user._id);

    if (user.watchlist.includes(movieId)) {
      return res.status(400).json({ message: 'Movie already in watchlist' });
    }

    user.watchlist.push(movieId);
    await user.save();

    res.json({ message: 'Movie added to watchlist', watchlist: user.watchlist });
  } catch (error) {
    handleControllerError(res, error);
  }
};

exports.removeMovieFromWatchlist = async (req, res) => {
  try {
    const { movieId } = req.params;
    const user = await User.findById(req.user._id);

    user.watchlist = user.watchlist.filter(
      (id) => id.toString() !== movieId
    );
    await user.save();

    res.json({ message: 'Movie removed from watchlist', watchlist: user.watchlist });
  } catch (error) {
    handleControllerError(res, error);
  }
};

exports.getUserWatchlist = async (req, res) => {
  try {
    // Alternatively, we could get req.user.id if they are fetching their own
    // The requirement says GET /api/watchlist/:userId
    const user = await User.findById(req.params.userId).populate('watchlist');
    
    if (user) {
      res.json(user.watchlist);
    } else {
      res.status(404).json({ message: 'User not found' });
    }
  } catch (error) {
    handleControllerError(res, error);
  }
};

const Profile = require('../models/Profile');
const { handleControllerError } = require('../utils/errorHandler');

// @desc    Create user profile
// @route   POST /api/profiles
// @access  Private
const createProfile = async (req, res) => {
  const { fullName, profilePicture, bio } = req.body;

  try {
    const profileExists = await Profile.findOne({ userId: req.user._id });

    if (profileExists) {
      return res.status(400).json({ message: 'Profile already exists for this user' });
    }

    const profile = await Profile.create({
      userId: req.user._id,
      fullName,
      profilePicture,
      bio,
    });

    res.status(201).json(profile);
  } catch (error) {
    handleControllerError(res, error);
  }
};

// @desc    Get user profile
// @route   GET /api/profiles/:id
// @access  Private
const getProfile = async (req, res) => {
  try {
    const profile = await Profile.findById(req.params.id).populate('userId', 'username email');

    if (profile) {
      res.json(profile);
    } else {
      res.status(404).json({ message: 'Profile not found' });
    }
  } catch (error) {
    handleControllerError(res, error);
  }
};

// @desc    Update user profile
// @route   PUT /api/profiles/:id
// @access  Private
const updateProfile = async (req, res) => {
  try {
    const profile = await Profile.findById(req.params.id);

    if (profile) {
      if (profile.userId.toString() !== req.user._id.toString()) {
        return res.status(401).json({ message: 'Not authorized to update this profile' });
      }

      profile.fullName = req.body.fullName || profile.fullName;
      profile.profilePicture = req.body.profilePicture || profile.profilePicture;
      profile.bio = req.body.bio || profile.bio;

      const updatedProfile = await profile.save();
      res.json(updatedProfile);
    } else {
      res.status(404).json({ message: 'Profile not found' });
    }
  } catch (error) {
    handleControllerError(res, error);
  }
};

// @desc    Delete user profile
// @route   DELETE /api/profiles/:id
// @access  Private
const deleteProfile = async (req, res) => {
  try {
    const profile = await Profile.findById(req.params.id);

    if (profile) {
      if (profile.userId.toString() !== req.user._id.toString()) {
        return res.status(401).json({ message: 'Not authorized to delete this profile' });
      }
      
      await Profile.deleteOne({ _id: req.params.id });
      res.json({ message: 'Profile removed' });
    } else {
      res.status(404).json({ message: 'Profile not found' });
    }
  } catch (error) {
    handleControllerError(res, error);
  }
};

module.exports = {
  createProfile,
  getProfile,
  updateProfile,
  deleteProfile,
};

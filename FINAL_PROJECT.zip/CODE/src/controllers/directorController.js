const Director = require('../models/Director');
const { handleControllerError } = require('../utils/errorHandler');

exports.createDirector = async (req, res) => {
  try {
    const director = await Director.create(req.body);
    res.status(201).json(director);
  } catch (error) {
    handleControllerError(res, error);
  }
};

exports.getDirectors = async (req, res) => {
  try {
    const directors = await Director.find({});
    res.json(directors);
  } catch (error) {
    handleControllerError(res, error);
  }
};

exports.getDirectorById = async (req, res) => {
  try {
    const director = await Director.findById(req.params.id);
    if (director) {
      res.json(director);
    } else {
      res.status(404).json({ message: 'Director not found' });
    }
  } catch (error) {
    handleControllerError(res, error);
  }
};

exports.updateDirector = async (req, res) => {
  try {
    const director = await Director.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true,
    });
    if (director) {
      res.json(director);
    } else {
      res.status(404).json({ message: 'Director not found' });
    }
  } catch (error) {
    handleControllerError(res, error);
  }
};

exports.deleteDirector = async (req, res) => {
  try {
    const director = await Director.findByIdAndDelete(req.params.id);
    if (director) {
      res.json({ message: 'Director removed' });
    } else {
      res.status(404).json({ message: 'Director not found' });
    }
  } catch (error) {
    handleControllerError(res, error);
  }
};

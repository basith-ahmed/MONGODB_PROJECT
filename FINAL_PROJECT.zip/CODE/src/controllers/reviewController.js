const Review = require('../models/Review');
const { handleControllerError } = require('../utils/errorHandler');

exports.createReview = async (req, res) => {
  try {
    const { movieId, reviewText, rating } = req.body;
    const review = await Review.create({
      movieId,
      userId: req.user._id,
      reviewText,
      rating,
    });
    res.status(201).json(review);
  } catch (error) {
    handleControllerError(res, error);
  }
};

exports.getReviews = async (req, res) => {
  try {
    const reviews = await Review.find({})
      .populate('userId', 'username')
      .populate('movieId', 'title');
    res.json(reviews);
  } catch (error) {
    handleControllerError(res, error);
  }
};

exports.getReviewById = async (req, res) => {
  try {
    const review = await Review.findById(req.params.id)
      .populate('userId', 'username')
      .populate('movieId', 'title');
    if (review) {
      res.json(review);
    } else {
      res.status(404).json({ message: 'Review not found' });
    }
  } catch (error) {
    handleControllerError(res, error);
  }
};

exports.updateReview = async (req, res) => {
  try {
    const review = await Review.findById(req.params.id);

    if (review) {
      if (review.userId.toString() !== req.user._id.toString()) {
        return res.status(401).json({ message: 'Not authorized to update this review' });
      }

      review.reviewText = req.body.reviewText || review.reviewText;
      review.rating = req.body.rating || review.rating;

      const updatedReview = await review.save();
      res.json(updatedReview);
    } else {
      res.status(404).json({ message: 'Review not found' });
    }
  } catch (error) {
    handleControllerError(res, error);
  }
};

exports.deleteReview = async (req, res) => {
  try {
    const review = await Review.findById(req.params.id);

    if (review) {
      if (review.userId.toString() !== req.user._id.toString()) {
        return res.status(401).json({ message: 'Not authorized to delete this review' });
      }

      await Review.deleteOne({ _id: req.params.id });
      res.json({ message: 'Review removed' });
    } else {
      res.status(404).json({ message: 'Review not found' });
    }
  } catch (error) {
    handleControllerError(res, error);
  }
};

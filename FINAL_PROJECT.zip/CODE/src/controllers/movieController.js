const Movie = require('../models/Movie');
const { handleControllerError } = require('../utils/errorHandler');

exports.createMovie = async (req, res) => {
  try {
    const movie = await Movie.create(req.body);
    res.status(201).json(movie);
  } catch (error) {
    handleControllerError(res, error);
  }
};

exports.getMovies = async (req, res) => {
  try {
    const movies = await Movie.find({})
      .populate('genreId', 'name')
      .populate('directorId', 'name');
    res.json(movies);
  } catch (error) {
    handleControllerError(res, error);
  }
};

exports.getMovieById = async (req, res) => {
  try {
    const movie = await Movie.findById(req.params.id)
      .populate('genreId', 'name description')
      .populate('directorId', 'name biography')
      .populate('actorIds', 'name nationality');
      
    if (movie) {
      res.json(movie);
    } else {
      res.status(404).json({ message: 'Movie not found' });
    }
  } catch (error) {
    handleControllerError(res, error);
  }
};

exports.updateMovie = async (req, res) => {
  try {
    const movie = await Movie.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true,
    });
    if (movie) {
      res.json(movie);
    } else {
      res.status(404).json({ message: 'Movie not found' });
    }
  } catch (error) {
    handleControllerError(res, error);
  }
};

exports.deleteMovie = async (req, res) => {
  try {
    const movie = await Movie.findByIdAndDelete(req.params.id);
    if (movie) {
      res.json({ message: 'Movie removed' });
    } else {
      res.status(404).json({ message: 'Movie not found' });
    }
  } catch (error) {
    handleControllerError(res, error);
  }
};

const mongoose = require('mongoose');

const movieSchema = new mongoose.Schema({
  title: {
    type: String,
    required: true,
    trim: true,
  },
  description: {
    type: String,
  },
  releaseYear: {
    type: Number,
  },
  duration: {
    type: Number, // duration in minutes
  },
  language: {
    type: String,
  },
  rating: {
    type: Number,
    min: 0,
    max: 10,
    default: 0,
  },
  genreId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Genre', // Many-to-One
  },
  directorId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Director', // One-to-Many (from Director's perspective)
  },
  actorIds: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Actor', // Many-to-Many
  }],
}, { timestamps: true });

const Movie = mongoose.model('Movie', movieSchema);
module.exports = Movie;

const mongoose = require('mongoose');

const actorSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
    trim: true,
  },
  dateOfBirth: {
    type: Date,
  },
  nationality: {
    type: String,
  },
  biography: {
    type: String,
  },
}, { timestamps: true });

const Actor = mongoose.model('Actor', actorSchema);
module.exports = Actor;

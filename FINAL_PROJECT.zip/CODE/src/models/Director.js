const mongoose = require('mongoose');

const directorSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
    trim: true,
  },
  dateOfBirth: {
    type: Date,
  },
  nationality: {
    type: String,
  },
  biography: {
    type: String,
  },
}, { timestamps: true });

const Director = mongoose.model('Director', directorSchema);
module.exports = Director;

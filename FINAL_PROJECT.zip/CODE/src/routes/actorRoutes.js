const express = require('express');
const router = express.Router();
const {
  createActor,
  getActors,
  getActorById,
  updateActor,
  deleteActor,
} = require('../controllers/actorController');
const validateObjectId = require('../middleware/validateObjectId');

router.param('id', validateObjectId);

/**
 * @swagger
 * tags:
 *   name: Actors
 *   description: Actor management
 */

/**
 * @swagger
 * /api/actors:
 *   post:
 *     summary: Create an actor
 *     tags: [Actors]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - name
 *             properties:
 *               name:
 *                 type: string
 *               dateOfBirth:
 *                 type: string
 *                 format: date
 *               nationality:
 *                 type: string
 *               biography:
 *                 type: string
 *     responses:
 *       201:
 *         description: Actor created
 */
router.post('/', createActor);

/**
 * @swagger
 * /api/actors:
 *   get:
 *     summary: Get all actors
 *     tags: [Actors]
 *     responses:
 *       200:
 *         description: List of actors
 */
router.get('/', getActors);

/**
 * @swagger
 * /api/actors/{id}:
 *   get:
 *     summary: Get actor by ID
 *     tags: [Actors]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Actor data
 */
router.get('/:id', getActorById);

/**
 * @swagger
 * /api/actors/{id}:
 *   put:
 *     summary: Update an actor
 *     tags: [Actors]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *     requestBody:
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               name:
 *                 type: string
 *               dateOfBirth:
 *                 type: string
 *                 format: date
 *               nationality:
 *                 type: string
 *               biography:
 *                 type: string
 *     responses:
 *       200:
 *         description: Actor updated
 */
router.put('/:id', updateActor);

/**
 * @swagger
 * /api/actors/{id}:
 *   delete:
 *     summary: Delete an actor
 *     tags: [Actors]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Actor deleted
 */
router.delete('/:id', deleteActor);

module.exports = router;

const express = require('express');
const router = express.Router();
const {
  createDirector,
  getDirectors,
  getDirectorById,
  updateDirector,
  deleteDirector,
} = require('../controllers/directorController');
const validateObjectId = require('../middleware/validateObjectId');

router.param('id', validateObjectId);

/**
 * @swagger
 * tags:
 *   name: Directors
 *   description: Director management
 */

/**
 * @swagger
 * /api/directors:
 *   post:
 *     summary: Create a director
 *     tags: [Directors]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - name
 *             properties:
 *               name:
 *                 type: string
 *               dateOfBirth:
 *                 type: string
 *                 format: date
 *               nationality:
 *                 type: string
 *               biography:
 *                 type: string
 *     responses:
 *       201:
 *         description: Director created
 */
router.post('/', createDirector);

/**
 * @swagger
 * /api/directors:
 *   get:
 *     summary: Get all directors
 *     tags: [Directors]
 *     responses:
 *       200:
 *         description: List of directors
 */
router.get('/', getDirectors);

/**
 * @swagger
 * /api/directors/{id}:
 *   get:
 *     summary: Get director by ID
 *     tags: [Directors]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Director data
 */
router.get('/:id', getDirectorById);

/**
 * @swagger
 * /api/directors/{id}:
 *   put:
 *     summary: Update a director
 *     tags: [Directors]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *     requestBody:
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               name:
 *                 type: string
 *               dateOfBirth:
 *                 type: string
 *                 format: date
 *               nationality:
 *                 type: string
 *               biography:
 *                 type: string
 *     responses:
 *       200:
 *         description: Director updated
 */
router.put('/:id', updateDirector);

/**
 * @swagger
 * /api/directors/{id}:
 *   delete:
 *     summary: Delete a director
 *     tags: [Directors]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Director deleted
 */
router.delete('/:id', deleteDirector);

module.exports = router;

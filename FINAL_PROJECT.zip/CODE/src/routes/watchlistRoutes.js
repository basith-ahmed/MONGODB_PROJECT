const express = require('express');
const router = express.Router();
const {
  addMovieToWatchlist,
  removeMovieFromWatchlist,
  getUserWatchlist,
} = require('../controllers/watchlistController');
const { protect } = require('../middleware/auth');
const validateObjectId = require('../middleware/validateObjectId');

router.param('movieId', validateObjectId);
router.param('userId', validateObjectId);

/**
 * @swagger
 * tags:
 *   name: Watchlist
 *   description: User Watchlist management
 */

/**
 * @swagger
 * /api/watchlist/add:
 *   post:
 *     summary: Add movie to watchlist
 *     tags: [Watchlist]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - movieId
 *             properties:
 *               movieId:
 *                 type: string
 *     responses:
 *       200:
 *         description: Movie added to watchlist
 */
router.post('/add', protect, addMovieToWatchlist);

/**
 * @swagger
 * /api/watchlist/remove/{movieId}:
 *   delete:
 *     summary: Remove movie from watchlist
 *     tags: [Watchlist]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: movieId
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Movie removed from watchlist
 */
router.delete('/remove/:movieId', protect, removeMovieFromWatchlist);

/**
 * @swagger
 * /api/watchlist/{userId}:
 *   get:
 *     summary: Get user watchlist
 *     tags: [Watchlist]
 *     parameters:
 *       - in: path
 *         name: userId
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: User's watchlist
 */
router.get('/:userId', getUserWatchlist);

module.exports = router;

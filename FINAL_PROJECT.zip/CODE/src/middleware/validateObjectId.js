const mongoose = require('mongoose');

/**
 * Express param middleware to validate MongoDB ObjectId parameters.
 * If the ID is invalid, it returns a 404 status with a friendly
 * "<Resource> not found" message based on the route baseUrl.
 */
const validateObjectId = (req, res, next, id) => {
  if (!mongoose.Types.ObjectId.isValid(id)) {
    const path = req.baseUrl || '';
    let resourceName = 'Resource';
    
    if (path.includes('users')) resourceName = 'User';
    else if (path.includes('movies')) resourceName = 'Movie';
    else if (path.includes('actors')) resourceName = 'Actor';
    else if (path.includes('directors')) resourceName = 'Director';
    else if (path.includes('genres')) resourceName = 'Genre';
    else if (path.includes('profiles')) resourceName = 'Profile';
    else if (path.includes('reviews')) resourceName = 'Review';
    else if (path.includes('watchlist')) resourceName = 'Watchlist';
    
    return res.status(404).json({ message: `${resourceName} not found` });
  }
  next();
};

module.exports = validateObjectId;

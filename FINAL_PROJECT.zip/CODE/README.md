# Movie Database Management System (DBMS) API

A RESTful backend API for managing a movie catalog, user authentication, profiles, reviews, and watchlists. Built using **Node.js**, **Express.js**, and **MongoDB/Mongoose**.

---

## Getting Started

Follow these steps to set up and run the project locally:

### 1. Install Dependencies

Install all required Node modules defined in `package.json`:

```bash
npm install
```

### 2. Configure Environment Variables

1. Create a `.env` file in the root directory of the project
2. Configure the following environment variables:

```env
PORT=3000
MONGODB_URI=your_mongodb_connection_string
JWT_SECRET=your_jwt_signing_secret
```

---

## Running the Application

### Development Mode

Runs the server using `nodemon`, which automatically restarts the server when code files change:

```bash
npm run dev
```

### Production Mode

Starts the server normally:

```bash
npm start
```

Once started, the server should run on `http://localhost:3000` (or your configured `PORT`).

---

## API Documentation

The project includes interactive API documentation built using **Swagger**.

While the server is running, navigate to:
**[http://localhost:3000/api-docs](http://localhost:3000/api-docs)**

From this interface, you can explore all available endpoints (Users, Profiles, Movies, Actors, Directors, Genres, Reviews, Watchlists) and send requests directly to the server to test functionality.
